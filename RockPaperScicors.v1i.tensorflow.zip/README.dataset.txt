# RockPaperScicors > 2024-02-27 2:56pm
https://universe.roboflow.com/machine-learning-p4m86/rockpaperscicors

Provided by a Roboflow user
License: CC BY 4.0

